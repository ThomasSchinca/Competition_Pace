Dear participant of the 2023/24 ViEWS Prediction Challenge,

Please follow these instructions to submit your predictions.

1. Make a copy of this folder, you can rename it to whatever you like (or keep it as is).
2. Produce predictions for these forecast windows and save the result in .parquet files:
	Jan 2018 - Dec 2018 using training data up until Oct 2017 (test_window_2018)
	Jan 2019 - Dec 2019 using training data up until Oct 2018 (test_window_2019)
	Jan 2020 - Dec 2020 using training data up until Oct 2019 (test_window_2020)
	Jan 2021 - Dec 2021 using training data up until Oct 2020 (test_window_2021)
2. You can make predictions for the country-level (cm) or the priogrid-level (pgm). The evaluation metrics (ignorance score) does not allow non-negative predictions, so you have to make sure your predictions are non-negative.
3. pgm-level files should have these column names: "month_id", "priogrid_gid", "draw", "outcome"
   cm-level files should have these column names: "month_id", "country_id", "draw", "outcome"
4. If you only submit point estimates, please still add the "draw" column name (with a 1 in each). Point predictions will be assumed to have a Poisson distribution as mentioned in the invitation (https://viewsforecasting.org/wp-content/uploads/VIEWS_2023.24_Prediction_Competition_Invitation.pdf).
   If you submit several prediction samples, please submit at least 15 and maximum 1000. Since our implementation of the ignorance score is only comparable with equal prediction samples, we will upscale predictions using scipy.signal.resample (https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.resample.html) if there are less than 1000 samples supplied when estimating ignorance score.
5. Put the .parquet file for the appropriate target-level (cm/pgm) and test window in the correct folder. It can be named whatever you like, but clear and descriptive names (possibly a version number) is useful for debugging purposes.
	Example: You have a "predictions.parquet" file with predictions for 2018 at the country-month level. 
		 This file should be placed in "submission_template/cm/test_window_2018".
6. Open submission_details.yml in a text-editor. Fill in the requested information.
	Make sure all authors and affiliations are included and correctly spelled.
7. Compress the folder to a .zip-file
8. Upload the .zip-file using the Dropbox file-request sent by the ViEWS team to you.
	Click "Add files" -> "Files from computer" and select your .zip-file.
	Note: Do not upload "Folders from computer" using the Dropbox file-request as this will not load files recursively, nor include the folders. You have to compress the folder to a zip-file before submitting.

Note: You can submit as many times as you want until 25 September. We will use the last submitted model in our evaluation. 
Note: If you are submitting multiple models for the same target-level, or different models for each target-level (requiring different meta-data), please set up multiple folders like this one and submit each separately. There should only be one .parquet file in each test_window_ folder!

If there are any concerns or questions, please email views-competition@prio.org with Paola Vesco (paoves@prio.org) and/or Jonas Vestby (jonves@prio.org) in cc.

Best regards,

The ViEWS team

